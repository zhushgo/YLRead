//
//  YLReadLongPressViewController.h
//  YLRead
//
//  Created by 苏沫离 on 2020/7/1.
//  Copyright © 2020 苏沫离. All rights reserved.
//

#import "YLReadViewController.h"

NS_ASSUME_NONNULL_BEGIN


@interface YLReadLongPressViewController : YLReadViewController

@end

NS_ASSUME_NONNULL_END
